import Portfolio from "@/components/Portfolio";

const Home = () => {
  return <Portfolio />;
};

export default Home;
